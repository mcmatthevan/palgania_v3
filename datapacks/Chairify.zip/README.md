# Chairify
A Minecraft Datapack to allow players to create functionals chairs spots in the world.

# Requires
- Minecraft 1.15+

# Use
1. Download the package and unzip it
2. Copy and rename the entire folder to "Chairify", then paste it in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map.

- Create a chair : /trigger ChairCreate
- Create a temporary chair : /trigger ChairSit
- Remove a chair : /trigger ChairRemove
- Uninstall : /function fkcf:uninstall

# Author
- Name : FunkyToc 
- Website : https://funkytoc.fr/en/home
- Contact : https://funkytoc.fr/en/contact

# Thanks 
...
